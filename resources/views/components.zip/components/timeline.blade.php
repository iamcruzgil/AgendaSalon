<ol class="items-center sm:flex">
    {{ $slot }}
</ol>
