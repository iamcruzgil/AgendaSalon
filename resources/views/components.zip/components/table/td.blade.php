<td {{ $attributes->merge(['class' => 'px-3 py-2.5 text-xs font-normal ']) }}>
    {{ $slot }}
</td>