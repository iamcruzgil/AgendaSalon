<th {{ $attributes->merge(['class' => 'px-3 py-3 text-xs uppercase font-medium tracking-wider '])
    }} scope="col">
    {{ $slot }}
</th>