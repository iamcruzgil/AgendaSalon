<span {{ $attributes->merge(['class' => 'text-xs font-normal mr-2 px-2.5 py-0.5 rounded dark:bg-blue-200 dark:text-blue-800']) }}>{{ $slot }}</span>
