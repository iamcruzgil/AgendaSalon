<button type="button" {{ $attributes->merge(['class' => 'text-indigo-700 hover:text-indigo-800 focus:outline-none
    focus:ring-offset-transparent']) }}>{{ $slot }}</button>
