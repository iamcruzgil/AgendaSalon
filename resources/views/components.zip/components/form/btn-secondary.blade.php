<button {{ $attributes->merge(['class' => ' bg-gray-800 text-white text-xs px-3 uppercase rounded-2xl
    hover:bg-gray-600 focus:outline-none focus:ring-offset-transparent']) }}>{{ $slot }}</button>