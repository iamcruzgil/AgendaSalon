<select {{ $attributes->merge(['class' => ' pr-7 pl-2 py-1.5 border border-blue-500 rounded text-xs select-text
    uppercase']) }} >
    {{ $slot }}
</select>
