<div class="px-4 pt-4 pb-2 shadow-lg rounded-lg bg-purple-800 hover:bg-indigo-600 border-t-4 border-fuchsia-500 ">
    <div class="text-white text-center  ">
        {{ $slot }}
    </div>
</div>
