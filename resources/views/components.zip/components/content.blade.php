<div class="">
    <div class=" m-2 px-2 py-4  bg-white border border-gray-500 rounded shadow-lg">
        <div class=" overflow-hidden ">
            <div class="px-2 ">
                {{ $slot }}
            </div>
        </div>
        {{ $import }}
    </div>


</div>