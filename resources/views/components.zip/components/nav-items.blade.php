<a {{ $attributes }} class="hover:bg-transparent bg-transparent">{{ $slot }}</a>
